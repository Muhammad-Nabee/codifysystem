<?php

namespace App\Http\Controllers;
use Response;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use App\Models\Assignproject;
use App\Models\Project;
use App\Models\Task;
use App\Models\Time_log;
use Session;
use DateTime;
use DatePeriod;
use DateInterval;
use Carbon\Carbon;




class ReportController extends Controller{
    
    
    public function report(){
        $user_total_time=array();
        $keys=array('name','id','total');
        $employe=User::where('role_id','2')->get(); 
        foreach ($employe as $user) {
            $task= Task::where('empolyee_id',$user->id)->get();
            $total="0 Hours 0 Minutes 0 Sec ";
            // for calculate current month total time that spends on tasks  
            foreach ($task as $t) {
                $hours=array();
                $hoursworked="0:0:0";
                $s=0;
                $m=0;
                $h=0;
                $i=0;
                $sec=0; 
                $min=0;
                $hou=0;
                $views=time_log::where('user_id',$t->empolyee_id)->whereMonth('start_date', date('m'))->get();
                foreach ($views as $view) {
                    if($views!=null){
                        $hoursworked="0 Hours 0 Minutes 0 Sec ";
                        $s=0;
                        $m=0;
                        $h=0;
                        if($view->end_time!=null){
                            $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                            $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                            $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                            if($s>=60){
                                $m=intval($s/60);
                                $s=$s-($m*60);
                            }
                            if($m>=60){
                                $h=intval($m/60);
                                $m=$m-($h*60);
                            }
                            $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";
                        }
                        $hours[]=$hoursworked;
                        $hou=$hou+$h;
                        $min=$min+$m;
                        $sec=$sec+$s;            
                        //seconds convert into minutes
                        $min  =$min+floor($sec/60);
                        $sec= $sec % 60;
                        //minutes convert into hours
                        $hou  =$hou+floor($min/60);
                        $min= $min % 60;
                        // dd($total);
                        $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
                    }
                }
            }
            array_push($user_total_time,array_combine($keys,[$user->user_name,$user->id,$total]));            
        }
        return view('employee.employeshow',compact('user_total_time'));
    }
      
    
    public function test($id){
        $user_total=array();
        $keys=array('p_title','title','task_id','task_status','total');
       
            $task= DB::table('users')->join('tasks','users.id','=','tasks.empolyee_id')->join('projects','tasks.project_id','=','projects.p_id')
            ->where('empolyee_id',$id)->get();
            foreach ($task as $t) {
                $hours=array();
                $hoursworked="0:0:0";
                $s=0;
                $m=0;
                $h=0;
                $i=0;
                $sec=0; 
                $min=0;
                $hou=0;
                $total="0 Hours 0 Minutes 0 Sec ";
                $views=time_log::where('user_id',$t->empolyee_id)->where('t_id',$t->task_id)->get();
                // ->where('start_date',Carbon::format('m'))->get();
                if($views!=null){
                    foreach ($views as $view) {
                        $hoursworked="0 Hours 0 Minutes 0 Sec ";
                        $s=0;
                        $m=0;
                        $h=0;
                        if($view->end_time!=null){
                            $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                            $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                            $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                            if($s>=60){
                                $m=intval($s/60);
                                $s=$s-($m*60);
                            }
                            if($m>=60){
                                $h=intval($m/60);
                                $m=$m-($h*60);
                            }
                            $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";
                        }
                        $hours[]=$hoursworked;
                        $hou=$hou+$h;
                        $min=$min+$m;
                        $sec=$sec+$s;

                        //seconds convert into minutes
                        $min  =$min+floor($sec/60);
                        $sec= $sec % 60;
                        //minutes convert into hours
                        $hou  =$hou+floor($min/60);
                        $min= $min % 60;
                        $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
                    }
                }
                array_push($user_total,array_combine($keys,[$t->p_title,$t->title,$t->task_id,$t->task_status,$total]));
            }
            // dd($user_total);
        
        return view('employee.Show_assign_task',compact('user_total'));
    }
    
    
    public function time_log($task_id){
        $time= DB::table('tasks')->join('time_log','tasks.task_id','=','t_id')
        ->select('tasks.title as title','time_log.start_date as start_date','time_log.end_date as end_date','time_log.start_time as start_time','time_log.end_time as end_time')
        ->where('t_id',$task_id)->get();
        //calculate starting and ending time difference
        $hours=array();
        $hoursworked="0:0:0";
        $s=0;
        $m=0;
        $h=0;
        $i=0;
        $sec=0;
        $min=0;
        $hou=0;
        $total="0 Hours 0 Minutes 0 Sec ";
        $views=time_log::where('t_id',$task_id)->get();
        if($views!=null){
            foreach ($views as $view) {
                $hoursworked="0 Hours 0 Minutes 0 Sec ";
                $s=0;
                $m=0;
                $h=0;
                if($view->end_time!=null){
                    $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                    $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                    $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                    if($s>=60){
                        $m=intval($s/60);
                        $s=$s-($m*60);
                    }
                    if($m>=60){
                        $h=intval($m/60);
                        $m=$m-($h*60);
                    }
                    $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";    
                }
                $hours[]=$hoursworked;
                $hou=$hou+$h;
                $min=$min+$m;
                $sec=$sec+$s;
                
                //seconds convert into minutes
                $min  =$min+floor($sec/60);
                $sec= $sec % 60;
                //minutes convert into hours
                $hou  =$hou+floor($min/60);
                $min= $min % 60;
                $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
            }
            return view('employee.Time_log',compact('time','hours','i'));
        }
    }

    public function Emp_time_log(){ 
        $emp_id=session('status')->id;
        $time= DB::table('tasks')->join('time_log','tasks.task_id','=','t_id')
        ->select('tasks.title as title','time_log.start_date as start_date','time_log.start_time as start_time','time_log.end_time as end_time')
        ->where('user_id',$emp_id)->get();
        //calculate starting and ending time difference
        $hours=array();
        $hoursworked="0:0:0";
        $s=0;
        $m=0;
        $h=0;
        $i=0;
        $sec=0;
        $min=0;
        $hou=0;
        $total="0 Hours 0 Minutes 0 Sec ";
        $views=time_log::where('user_id',$emp_id)->get();
        if($views!=null){
            foreach ($views as $view) {
                $hoursworked="0 Hours 0 Minutes 0 Sec ";
                $s=0;
                $m=0;
                $h=0;
                if($view->end_time!=null){
                    $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                    $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                    $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                    if($s>=60){
                        $m=intval($s/60);
                        $s=$s-($m*60);
                    }
                    if($m>=60){
                        $h=intval($m/60);
                        $m=$m-($h*60);
                    }
                    $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";    
                }
                $hours[]=$hoursworked;
                $hou=$hou+$h;
                $min=$min+$m;
                $sec=$sec+$s;
                
                //seconds convert into minutes
                $min  =$min+floor($sec/60);
                $sec= $sec % 60;
                //minutes convert into hours
                $hou  =$hou+floor($min/60);
                $min= $min % 60;
                $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
            }

        }
        return view('employee.Emp_time_log',compact('time','hours','i','total'));
    }
    
    
    public function today_task(){ 
        $current_date= date('Y-m-d');
        $user=array();
        $keys=array('user_name','title','start_time','end_time','total');
       
            $task= DB::table('users')->join('tasks','users.id','=','tasks.empolyee_id')->join('time_log','empolyee_id','=','time_log.user_id')
            ->where('time_log.start_date',$current_date)->get();
            
            foreach ($task as $t) {
                $hours=array();
                $hoursworked="0:0:0";
                $s=0;
                $m=0;
                $h=0;
                $i=0;
                $sec=0; 
                $min=0;
                $hou=0;
                $total="0 Hours 0 Minutes 0 Sec ";
                $views=time_log::where('user_id',$t->user_id)->where('start_date',$current_date)->get();
                // ->where('start_date',Carbon::format('m'))->get();
                // dd($views);
                if($views!=null){
                    foreach ($views as $view) {
                        $hoursworked="0 Hours 0 Minutes 0 Sec ";
                        $s=0;
                        $m=0;
                        $h=0;
                        if($view->end_time!=null){
                            $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                            $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                            $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                            if($s>=60){
                                $m=intval($s/60);
                                $s=$s-($m*60);
                            }
                            if($m>=60){
                                $h=intval($m/60);
                                $m=$m-($h*60);
                            }
                            $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";
                        }
                        $hours[]=$hoursworked;
                        $hou=$hou+$h;
                        $min=$min+$m;
                        $sec=$sec+$s;

                        //seconds convert into minutes
                        $min  =$min+floor($sec/60);
                        $sec= $sec % 60;
                        //minutes convert into hours
                        $hou  =$hou+floor($min/60);
                        $min= $min % 60;
                        $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
                    }
                }
                array_push($user,array_combine($keys,[$t->user_name,$t->title,$t->start_time,$t->end_time,$total]));

            }
        
        return view('employee.today_task',compact('user'));

    }

    public function emp_view(Request $request,$id){
        $user=User::where('id',$id)->first(); 
        // dd($ok);
        if($user){
        if($user->id==$id){ 
              $request->session()->put('status',$user);
            return redirect()->action([EmployeeController::class,'empDashboard']);
        }
        else{
            dd("hello");
            // return redirect(employees);
        }}

        // $user=User::where('role_id','2')->get();
        // $stat=session('status')->id;
        // dd($id);
        // $date1=date('y');
        // $date2=date('m');
        // $date3=date('d');   
        // $date4='COD-Emp-'.$date3.'/'.$date2.'/'.$date1;
        // $cd=$user->id+1;
        // $int_no=$date4.$cd; 
        // dd($int_no); 

    }


    
}    
   
    
    