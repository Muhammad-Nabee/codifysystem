<?php

namespace App\Http\Controllers;
use Response;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use App\Models\Assignproject;
use App\Models\Project;
use App\Models\Task;
use App\Models\Time_log;
use Session;
use DateTime;
use DatePeriod;
use DateInterval;




class EmployeeController extends Controller{


    public function empDashboard(){
        $emp_id=session('status')->id;
        
        $current_date= date('Y-m-d');
        
        $time_log=time_log::where('user_id',$emp_id)->where('end_time',Null)->where('start_date',$current_date)->first();
        $ho=0;
        $mi=0;
        $se=0;
        $current_time = date('H:i:s');
        if($time_log!=null){
            $hoursworked="0 Hours 0 Minutes 0 Sec ";
            $s=0;
            $m=0;
            $h=0;
            $sec=0; 
            $min=0;
            $hou=0;
           
            if($time_log->end_time==null){
                $start_time=DateTime::createFromFormat('H:i:s',$time_log->start_time);
                $current_time=DateTime::createFromFormat('H:i:s',$current_time);
                $s=intval(round(($current_time->format('U') - $start_time->format('U'))));
                if($s>=60){
                    $m=intval($s/60);
                    $s=$s-($m*60);
                }
                if($m>=60){
                    $h=intval($m/60);
                    $m=$m-($h*60);
                }
                $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";
            }
            $hours[]=$hoursworked;
            $hou=$hou+$h;
            $min=$min+$m;
            $sec=$sec+$s;            
            //seconds convert into minutes
            $min  =$min+floor($sec/60);
            $sec= $sec % 60;
            //minutes convert into hours
            $hou  =$hou+floor($min/60);
            $min= $min % 60;
            // dd($total);
            $ho=$hou;
            $mi=$min;
            $se=$sec;     
        }
        
        
        
            
        
        ///pfdgflhdlhgdfkjhgfdkjhg
        $task= Task::where('empolyee_id',$emp_id)->get();
        $total="0 Hours 0 Minutes 0 Sec ";
        // for calculate current month total time that spends on tasks  
        foreach ($task as $t) {
            $hours=array();
            $hoursworked="0:0:0";
            $s=0;
            $m=0;
            $h=0;
            $i=0;
            $sec=0; 
            $min=0;
            $hou=0;
            $views=time_log::where('user_id',$t->empolyee_id)->whereMonth('start_date', date('m'))->get();
            foreach ($views as $view) {
                if($views!=null){
                    $hoursworked="0 Hours 0 Minutes 0 Sec ";
                    $s=0;
                    $m=0;
                    $h=0;
                    if($view->end_time!=null){
                        $start_time=DateTime::createFromFormat('H:i:s',$view->start_time);
                        $end_time=DateTime::createFromFormat('H:i:s',$view->end_time);
                        $s=intval(round(($end_time->format('U') - $start_time->format('U'))));
                        if($s>=60){
                            $m=intval($s/60);
                            $s=$s-($m*60);
                        }
                        if($m>=60){
                            $h=intval($m/60);
                            $m=$m-($h*60);
                        }
                        $hoursworked=$h." Hours ".$m." Minutes ".$s." Sec ";
                    }
                    $hours[]=$hoursworked;
                    $hou=$hou+$h;
                    $min=$min+$m;
                    $sec=$sec+$s;            
                    //seconds convert into minutes
                    $min  =$min+floor($sec/60);
                    $sec= $sec % 60;
                    //minutes convert into hours
                    $hou  =$hou+floor($min/60);
                    $min= $min % 60;
                    // dd($total);
                    $total=$hou." Hours ".$min." Minutes ".$sec." Sec ";
                    
                }
            }
        }
        $data1=DB::table('tasks')->where('empolyee_id',$emp_id)->get();
        $assign_p_data=DB::table('assignprojects')->where('emp_id',$emp_id)->get();
        $p_array=array();
        $keys=array('p_id','title','desc','deadline','status');
        foreach ($assign_p_data as $data) {
            
            $project_info=DB::table('projects')->where('p_id',$data->project_id)->first(); 
            array_push($p_array,array_combine($keys,[$project_info->p_id ?? '',$project_info->p_title ?? '',$project_info->p_description ?? '',$project_info->p_deadline ?? '',$data->p_status ?? '']));
        };
        
        $firstdata=Time_log::where('user_id',$emp_id)->where('end_time',NULL)->where('start_date',$current_date)->first();
        
        return view('employee.employeeDashboard',compact('firstdata','p_array','emp_id','data1','total','ho','se','mi'));
        
    }
    
    public function employeeTask(Request $request){
        $emp_id=session('status')->id;
        $task_admin = new Task;
        $task_admin->project_id =$request->input('p_id');
        $task_admin->title=$request->input('task_name');
        $task_admin->start_date=$request->input('task_start_date');
        $task_admin->end_date=$request->input('task_end_date');
        $task_admin->empolyee_id =session('status')->id;
        $task_admin->task_status=-1;
        $task_admin->save();
        
        return back()->with('task','Record added successfully !');
    }
    public function createTask(){
        $emp_id=session('status')->id;
        $assign_p_data=DB::table('assignprojects')->where('emp_id',$emp_id)->get();
        $p_array=array();
        $keys=array('p_id','title','desc','deadline','status');
        foreach ($assign_p_data as $data) {
            
            $project_info=DB::table('projects')->where('p_id',$data->project_id)->first(); 
            array_push($p_array,array_combine($keys,[$project_info->p_id ?? '',$project_info->p_title ?? '',$project_info->p_description ?? '',$project_info->p_deadline ?? '',$data->p_status ?? '']));
        };
        
        $project=Project::all();
        $data=Task::where('empolyee_id',session('status')->id)->get();
        

        
        return view('employee.createTask', compact('data','p_array'));
    }
    
    public function show_tasks($task_id){
        $edit_task = Task::find($task_id);
        return view('employee.emp_edit_task',compact('edit_task'));
    }
    
    public function UpdateTasks(Request $request){
        $edit_task = Task::find($request->task_id);
        $edit_task->title=$request->up_title;
        $edit_task->start_date=$request->up_start_date;
        $edit_task->end_date=$request->up_end_date;
        $edit_task->save();
        return redirect('createTask')->with('taskupdate','Record Updated successfully!');
    }
    
    
    public function change_status_progres($task_id){
        $edit_task = Task::find($task_id);
        
        // dd($edit_task);
        $edit_task->task_status=-1;
        $edit_task->save();
        return redirect('createTask')->with('taskupdate','Status Updated Successfully!');
        
    }
    
    public function change_status__completed($task_id){
        $edit_task = Task::find($task_id);
        $edit_task->task_status=1;
        $edit_task->save();
        return redirect('createTask')->with('taskupdate','Status Updated Successfully');
        
        
    }
    
    public function change_status_pause($task_id){
        $edit_task =Task::find($task_id);
        $edit_task->task_status=5;
        $edit_task->save();
        return redirect('createTask')->with('taskupdate','Status Updated Successfully');
    }
    
    public function change_status_approval($task_id){
        $edit_task=Task::find($task_id);
        $edit_task->task_status=4 ;
        $edit_task->save();
        return redirect('createTask')->with('Admin Approval','Status Updated Successfully');
    } 
    
    
    
    public function posttask(Request $req)
    {
        
        $data = Task::where('project_id',$req->id)->where('empolyee_id',session('status')->id)->get();
        
        $dataarray=array();
        $keys=array('title','task_id');
        foreach($data as $p_task){
            //array_push($dataarray,[$p_task->title],[$p_task->task_id]); 
            array_push($dataarray,array_combine($keys,[$p_task->title ,$p_task->task_id]));     
        }
        
        return response()->json([
            'dataarray'=>$dataarray,
        ],200);
        
        // return Response()->json($data);
    }
    
    public function assignProject(){
        
        $emp_id=session('status')->id;
        $assign_p_data=DB::table('assignprojects')->where('emp_id',$emp_id)->get();
        $p_array=array();
        $keys=array('p_id','title','desc','deadline','status');
        foreach ($assign_p_data as $data) {
            
            $project_info=DB::table('projects')->where('p_id',$data->project_id)->first(); 
            array_push($p_array,array_combine($keys,[$project_info->p_id,$project_info->p_title,$project_info->p_description,$project_info->p_deadline,$data->p_status]));
        };
        return view('employee.assignProject',compact('p_array','emp_id'));   
        
    }

    
    
    public function addtask(Request $request)
    {
        $emp_id=session('status')->id;
        $p_id=$request->input('p_id');
        $t_id=$request->input('t_id');
        $current_date = date('Y-m-d');
        $current_time = date('H:i:s');
        
        $add=Time_log::create([
            'user_id'=>$emp_id,
            'p_id'=>$p_id,
            't_id'=>$t_id,
            'start_date'=>$current_date,
           'start_time'=>$current_time,
        ]);
        //return back()->with('message','Task started');
        return response()->json([
            'id'=>$add->id,
            'message'=>'Task started',
        ],200);
        
    }
    
    public function completetask(Request $request,$id)
    {  
       
        $end_time = date('H:i:s');
        $data=Time_log::where('id',$id)->where('end_time',Null)->first();
        $data->end_time=$end_time;
        
        $data->save();
        return back()->with('message',"Your task has been successfully completed");
    }
    
    //User profile
    public function Userprofile()
    {
        $emp_id=session('status')->id;
        $data=DB::table('users')->where('id',$emp_id)->first();
        return view('employee.userprofile',compact('data'));

    }

    public function updateprofile(Request $request)
    {
        $data= User::find($request->input('id'));
        $data->user_name=$request->input('user_name');
        $data->phone=$request->input('phone');
        $data->password=md5($request->input('password'));

        if($request->hasfile('image')){
        $destination='public/userprofile/'.$data->image;
        if(File::exists($destination))
        {
            File::delete($destination);
        }
        $file = $request->file('image');
        $extension = $file->getClientOriginalExtension();
        $filename = time() . '.' . $extension;
        $file->move('public/userprofile/', $filename);
        $data->image= $filename;
       }else{
        return $request;
        $user->image = '';

    }
    $data->update();
    return redirect()->back();
    }
}


?>