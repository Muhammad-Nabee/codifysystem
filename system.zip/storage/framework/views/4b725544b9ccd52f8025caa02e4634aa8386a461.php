<?php $__env->startSection('css_links'); ?>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">

<?php $__env->startSection('content'); ?>

      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>

</style>



<div class="container-fluid p-0">
  <div class="row mt-3 justify-content-between">
   
  <div class="col-md-3 col-xl-3">
    <div class="card bg-light border border-top-0 p-4" style="max-width: 20rem;">
  <div class="card-body text-dark">
    <span class="card-title">Number<i class="fa fa-address-card-o float-right" style="font-size: 30px;" aria-hidden="true" ></i> </span><br>
    <span class="card-title">Title</span>
  </div>
  <div class="card-footer text-center"><a href="">More...</a>
  </div>
</div>
  </div>

  <div class="col-md-3 col-xl-3">
    <div class="card bg-light border border-top-0 p-4" style="max-width: 20rem;">
  <div class="card-body text-dark">
   <span class="card-title">Number<i class="fa fa-address-card-o float-right"style="font-size: 30px; aria-hidden="true"></i></span><br>
    <span class="card-title">Title</span>
  </div>
  <div class="card-footer text-center"><a href="">More...</a></div>
</div>
  </div>

  <div class="col-md-3 col-xl-3">
    <div class="card bg-light border border-top-0 p-4" style="max-width: 20rem;">
  <div class="card-body text-dark">
     <span class="card-title">Number<i class="fa fa-address-card-o float-right"style="font-size: 30px; aria-hidden="true"></i></span><br>
    <span class="card-title">Title</span>
  </div>
  <div class="card-footer  text-center"><a href="">More...</a></div>
</div>
  </div>

  <div class="col-md-3 col-xl-3">
    <div class="card bg-light border border-top-0 p-4" style="max-width: 20rem;">
  <div class="card-body text-dark">
     <span class="card-title">Number<i class="fa fa-address-card-o float-right"style="font-size: 30px; aria-hidden="true"></i></span><br>
    <span class="card-title">Title</span>
  </div>
  <div class="card-footer  text-center"><a href="">More...</a></div>
</div>
  </div>

</div>
</div>






<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_link'); ?>
<?php echo $__env->make('includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/codifypk/system.codify.pk/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>