<?php $__env->startSection('css_links'); ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">


<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
      </div>
      <div class="row">
        <div class="col">       
				<table class="table" id="myTable">
          <thead class="thead-dark">
            <tr>
              <th>#</th>
              <th>Project Name</th>
              <th>Task Name</th>
              <th>Total Task Time</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $i=0;?>
            <?php $__currentLoopData = $user_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tasks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++;?>
                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($tasks['p_title']); ?></td>
                    <td><?php echo e($tasks['title']); ?></td>
                    <td><?php echo e($tasks['total']); ?></td>
                    <?php if($tasks['task_status']==1): ?>
                    <td class="bg-success text-center text-white">
                      Complete
                    </td>
                    <?php elseif($tasks['task_status']==-1): ?>
                    <td class="bg-info text-center text-white">
                      Progress
                    </td>
                    <?php elseif($tasks['task_status']==3): ?>
                    <td class="bg-danger text-center text-white">
                      Rejected
                    </td>
                    <?php elseif($tasks['task_status']==0): ?>
                    <td class="bg-primary text-center text-white">
                      panding			
                    </td>
                    <?php elseif($tasks['task_status']==4): ?>
                    <td class="bg-secondary text-center text-white">
                      Admin Approval
                    </td>
                    <?php elseif($tasks['task_status']==5): ?>
                    <td class="bg-warning text-center text-white">
                      Pause
                    </td>
                    <?php endif; ?>                 
                    <td>
                      <a href="<?php echo e(route('time_log',$tasks['task_id'])); ?>"><button  class="btn btn-secondary">Task Time</button></a>            
                    </td>
                  </tr>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <?php $__env->stopSection(); ?>
        
        <?php $__env->startSection('js_link'); ?>
        <script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/codifypk/system.codify.pk/resources/views/employee/Show_assign_task.blade.php ENDPATH**/ ?>