    <!-- BEGIN: Footer-->

    <footer class="footer footer-static footer-light">

        <p style="color: black;" class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; <?php echo e(date('D/M/Y')); ?> <i>Codify</i><span style="color: black;" class="d-none d-sm-inline-block">, All rights Reserved</span></span><span style="color: black;" class="float-md-right d-none d-md-block">Hand-crafted & Made with<i data-feather="heart"></i></span></p>

    </footer>

    <button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>

    <!-- END: Footer-->





    <?php /**PATH /home2/codifypk/system.codify.pk/resources/views/includes/footer.blade.php ENDPATH**/ ?>