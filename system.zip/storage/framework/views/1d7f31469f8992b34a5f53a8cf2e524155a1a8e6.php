<?php $__env->startSection('css_links'); ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
  


<?php $__env->startSection('content'); ?>



<div class="container">
	<div class="row">
		<div class="col">
			<form action="<?php echo e(route('project_assign_employee')); ?>" method="POST" enctype="multipart/form-data">
        

        <h3 style="background: #eaeac2; padding: 15px;text-align: center;border-radius: 5px;">Projects Assign To Empolyee</h3>
                                      <?php if(Session::has('pro_assign')): ?>
                                        <div class="alert alert-danger">
                                        <?php echo e(Session::get('pro_assign')); ?>

                                        </div>
                                      <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                            <input type="" value="<?php echo e($id); ?>" name="project_id" hidden="">
                                            <div class="row">
                                                <div class="col-4">

                                                    <label>Empolyee</label>
                                                      <select class="form-control" style="width: 215px;height: 35px;border-radius: 5px;" name="emp_name"id="">
                                                         <?php $__currentLoopData = $empolyee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                          <option value="<?php echo e($emp->id); ?>"> 
                                                            <?php echo e($emp->user_name); ?> 
                                                          </option>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                       </select>
                                                  </div>

                                                  <div class="col-4">
                                                    <label>Assign Date</label>
                                                    <input type="date" name="assign_date" class="form-control"required >
                                                  </div>
                                                  <div class="col-4">
                                                    <label>Deadline</label>
                                                      <input type="date" name="deadline_date" class="form-control"required >
                                                  </div>
                                            </div>
                                                  
                                                  

                                            <div class="row mt-5">
                                              <div class="col-md-12 text-center">
                                                <button  type="submit" class="btn btn-lg btn-primary">Assign</button>
                                                        
                                              </div>
                                                      
                                            </div>
                                                  
                                                      
                                                    
                                            </form>

			
		</div>
	</div>
  <div class="row">
    <div class="col">
      <table class="table table-hover table-bordered table-striped mt-2">
        <?php if(Session::has('ass_emp_delete')): ?>
        <div class="alert alert-danger mt-2">
        <?php echo e(Session::get('ass_emp_delete')); ?>

        </div>
        <?php endif; ?>
        <thead>
          <tr>
          <th>Employee Name</th>
          <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $emp_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($empname['name']); ?></td>
            <!-- <td><img class="img-fluid rounded" src="<?php echo e(asset('public/image/'.$empname['image'])); ?>" width="70" height="70" /></td> -->
            <td><a class="btn btn-primary" href="<?php echo e(route('assign_empolyee_delete',$empname['assign_id'])); ?>">Delete</a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
      </table>
      
    </div>
    
  </div>
</div>
























<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_link'); ?>



<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/codifypk/system.codify.pk/resources/views/admin/assignempolyee.blade.php ENDPATH**/ ?>