<?php $__env->startSection('css_link'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/app-assets/vendors/css/charts/apexcharts.css')); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/app-assets/css/plugins/charts/chart-apex.css')); ?>">


<?php $__env->startSection('content'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<section id="dashboard-ecommerce">
  <!-- <h1>We are in employee</h1> -->
  
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('message')); ?>

  </div>
  <?php endif; ?>
  <?php if($firstdata!=null): ?>
  <a href="<?php echo e(route('/completetask',$firstdata->id)); ?>"><button  type="button" class="btn btn-primary float-right click" id="click">
    Stop
  </button></a> 
  <?php else: ?>
  <button  type="button" onclick="reset();" id="startStop" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">
    Start Task
  </button>
  <?php endif; ?>
  
  <div class="showstopbutton">
    
    
    </div>
    <div class="modal fade " id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Start Task</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form >
              <tr>
                <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                <p>Project Name</p>
                <select class="form-control name p_id" name="title" id="p_id" >
                    <option>--Select Project--</option>
                  <?php $__currentLoopData = $p_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <option value="<?php echo e($item['p_id']); ?>">
                    <?php echo e($item['title']); ?>

                  </option>
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <p>Task Title</p>
                <select id="data" name="t_id" class="form-control">
                  
                  </select>
                  <input class="btn btn-primary float-right" id="add-writer-btn" type="button" value="Submit">
                </form>
                
                
              </div>
            </div>
          </div>
        </div>
        
        <div id="display" style="margin-left: 580px; margin-top: 15px;">
          <!-- 00:00:00 -->
        </div>
        
        <!-- <div class="button">
          <button id="startStop" onclick="reset()">Start</button>
          <button id="reset" onclick="reset()">Reset</button>
        </div> -->
        
        
      </section>
      <div class="id"></div>
      
      <h6 style="text-align: center">current month total time=<?php echo e($total); ?> </h6>
      
      
      
      
      <input type="hidden" class="hou" value="<?php echo e($ho); ?>">
      <input type="hidden" class="min" value="<?php echo e($mi); ?>">
      <input type="hidden" class="sec" value="<?php echo e($se); ?>">
      <script>
        $(document).ready( function () {
          $('.name').change( function(){
            
            var id =$('.name').val();
            var token=$('#csrf-token').val();
            
            $.ajax({
              type: "get",
              url: "<?php echo e(route('posttask')); ?>",
              data: {
                "token":token,
                'id' :id,
              },
              
              success: function(response){
                $('#data').empty();
                for(var i=0; i<response.dataarray.length; i++)
                {
                  
                  $('#data').append(`<option value="`+response.dataarray[i].task_id+`">`+response.dataarray[i].title+`</option>`);
                }
                
              }
              
            });
          });
        });
        </script>

<script>
  $(document).ready(function() {
    $('#add-writer-btn').on('click', function() {
      var p_id = $('#p_id').val();
      var t_id =$('#data').val();
      var token=$('#csrf-token').val();
      $.ajax({
        url: "<?php echo e(route('addtask')); ?>",
        method: "get",
        data: {
          "token":token,
          "p_id": p_id,
          "t_id": t_id
          
        },
        success:function(message){
          $('.id').empty();
          $('.id').append(`<input type="hidden" class="get" value="`+message.id+`">`);
          $('#exampleModal').modal('hide');
          $('#startStop').hide();
          var id=message.id;
          var url1="<?php echo e(route('/completetask')); ?>"+'/'+id;
          $('.showstopbutton').append(`<a href="`+url1+`"><button  type="button" class="btn btn-primary float-right click" id="click">
          Stop
          </button></a>`);
          let seconds=0;
          let minutes=0;
          let hours=0;
          
          let displaySeconds=0;
          let displayMinutes=0;
          let displayHours=0;
          
          // define ver to hold setInterval{} function
          let interval= null;
          
          //define ver to hold stopwatch status
          let status = "stopped";
          
          // stopwatch function
          function stopwatch() {
            seconds++;
            
            if(seconds / 60 ===1){
              seconds = 0;
              minutes++;
              
              if (minutes / 60 ===1) {
                minutes =0;
                hours++;
              }
            }
            //if second/minute/hour is only one digit.add leading 0 to the value
            if (seconds < 10 ) {
              displaySeconds = "0" + seconds.toString();
            }else{
              displaySeconds = seconds;
            }
            
            if (minutes < 10 ) {
              displayMinutes = "0" + minutes.toString();
            }else{
              displayMinutes = minutes;
            }
            
            if (hours < 10 ) {
              displayHours = "0" + hours.toString();
            }else{
              displayHours = hours;
            }
            
            //display updated time to user
            document.getElementById('display').innerHTML =displayHours +":" +displayMinutes +":" +displaySeconds;
          }
          
          $(document).ready( function () {
            if (status === "stopped") {
              interval=window.setInterval(stopwatch, 1000);
              document.getElementById("startStop").innerHTML = "Stop";
              status ="started";
            }
            /*else{
              window.clearInterval(interval);
              document.getElementById("startStop").innerHTML = "Start";
              status="stopped";
            }*/
          });
          
          function reset(){
            if (status === "started") {
              window.clearInterval(interval);
              seconds=0;
              minutes=0;
              hours=0;
              document.getElementById("display").innerHTML ="00:00:00";
              document.getElementById("startStop").innerHTML = "Start";
              status ="started";
              
            }
          }
        }
      });
    });
  });
</script>
<?php if($firstdata!==null): ?>
<script>
  $(document).ready( function () {
    var hou =$('.hou').val();
    var min =$('.min').val();
    var sec =$('.sec').val();
    
    let seconds=sec;
    let minutes=min;
    let hours=hou;
    
    let displaySeconds=sec;
    let displayMinutes=min;
    let displayHours=hou;
    
    // define ver to hold setInterval{} function
    let interval= null;
    
    //define ver to hold stopwatch status
    let status = "stopped";
    
    // stopwatch function
    function stopwatch() {
      seconds++;
      
      if(seconds / 60 ===1){
        seconds = 0;
        minutes++;
        
        if (minutes / 60 ===1) {
          minutes =0;
          hours++;
        }
      }
      //if second/minute/hour is only one digit.add leading 0 to the value
      if (seconds < 10 ) {
        displaySeconds = "0" + seconds.toString();
      }else{
        displaySeconds = seconds;
      }
      
      if (minutes < 10 ) {
        displayMinutes = "0" + minutes.toString();
      }else{
        displayMinutes = minutes;
      }
      
      if (hours < 10 ) {
        displayHours = "0" + hours.toString();
      }else{
        displayHours = hours;
      }
      
      //display updated time to user
      document.getElementById('display').innerHTML =displayHours +":" +displayMinutes +":" +displaySeconds;
    }
    
    $(document).ready( function () {
      if (status === "stopped") {
        interval=window.setInterval(stopwatch, 1000);
        document.getElementById("startStop").innerHTML = "Stop";
        status ="started";
      }
      /*else{
        window.clearInterval(interval);
        document.getElementById("startStop").innerHTML = "Start";
        status="stopped";
      }*/
    });
    
    
  });
</script>
<?php endif; ?>
<!-- <script>
  window.onload = function(){
    document.getElementById('click').click();
  }
</script> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_link'); ?>

<script src="<?php echo e(asset('public/app-assets/js/scripts/pages/dashboard-ecommerce.js')); ?>"></script>

<script src="<?php echo e(asset('public/app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/codifypk/system.codify.pk/resources/views/employee/employeeDashboard.blade.php ENDPATH**/ ?>