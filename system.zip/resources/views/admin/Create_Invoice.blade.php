@extends('includes.master')

@section('css_links')

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
@section('content')
	<div class="container">
		 <div class="row">
			<div class="col"> 
				
                    <form action="{{route('Store_Invoice')}}" method="POST" enctype="multipart/form-data">
                      <div class="row">
                        <div class="col">
                            <label>Projects</label>
                            <select  name="project_id"id="project_id" class="form-control">
                            @foreach($Get_AllProject as $pro)

                            <option value="{{$pro->p_id}}"> 
                            {{$pro->p_title}} 
                            </option>
                            @endforeach 
                            </select>
                        </div>
                        <div class="col">
                            <label>Clients</label>
                            <select  name="client_id"id="clients" class="form-control">
                            @foreach($clients as $client)

                            <option value="{{$client->id}}"> 
                            {{$client->user_name}} 
                            </option>
                            @endforeach 
                            </select>
                        </div>
                    </div>
                        <table class="table table-hover table-bordered mt-2">
                    @csrf
                            <tr>
                                
                                <td>
                                    <input type="text" name="item[]" placeholder="item" class="form-control">
                                </td>
                                
                                 <td>
                                    <input type="text" name="price[]" placeholder="Quantity" class="form-control">
                                </td>
                                
                                <td>
                                    <input type="text" name="quantity[]" placeholder="Price" class="form-control">
                                </td>
                                <td><button type="button" class="btn btn-primary" id="add_btn"><i class="fas fa-plus-circle"></i></button></td>
                            </tr>
                      
                    </table>
                    <div class="row">
                        <div class="col">
                            <label>Description</label>
                            <textarea class="form-control" cols="4" rows="4" name="invoice_desc"></textarea>
                            
                        </div>
                        
                    </div>
                    <button type="submit" class="btn btn-primary mt-2 float-right">Submit</button>
                            
                </form>
				
			 </div>
		</div> 
	</div>


@stop

@section('js_link')

<script type="text/javascript">
    $(document).ready(function(){
      $('#add_btn').on('click',function(){
        //alert(); //by clicking button check button
        var html='';  //declear variable
        //console.log(html);
          html+='<tr>';
          html+='<td><input type="text" name="item[]" placeholder="item" class="form-control"></td>';
          html+='<td><input type="text" name="price[]" placeholder="Quantity" class="form-control"></td>';
          html+='<td><input type="text" name="quantity[]" placeholder="Price" class="form-control"></td>';
          html+='<td><button type="button" class="btn btn-danger" id="remove"><i class="fal fa-comment-alt-times"></i></button></td>';
          html+='</tr>';
          $('tbody').append(html);
      })

    });

    $(document).on('click','#remove',function(){
      //alert();
      $(this).closest('tr').remove();

    });
  </script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

@stop