@extends('includes.master1')

@section('css_link')

<link rel="stylesheet" type="text/css" href="{{asset('public/app-assets/vendors/css/charts/apexcharts.css')}}">

<link rel="stylesheet" type="text/css" href="{{asset('public/app-assets/css/plugins/charts/chart-apex.css')}}">


@section('content')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

                <section id="dashboard-ecommerce">

                  <div class="container">
                    <div class="row">
                      <div class="col-md-8">
                        <form action="{{route('updateprofile')}}" method="post" enctype="multipart/form-data" style="margin-left: 250px;">
                    <div class="form-group">
                      @csrf
                      <input type="hidden" name="id" value="{{$data->id}}">
                      <label>Name:</label>
                      <input type="text" name="user_name" value="{{$data->user_name}}" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>Password:</label>
                      <input type="password" name="password" value="{{$data->password}}" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>Phone No:</label>
                      <input type="text" name="phone" value="{{$data->phone}}" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>Image:</label>
                      
                      <input type="file" name="image" value="{{$data->image}}" class="form-control">
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" class="btn btn-primary">
                    </div>
                  </form>
                      </div>
                    </div>
                  </div>

                </section>
@stop

@section('js_link')

<script src="{{asset('public/app-assets/js/scripts/pages/dashboard-ecommerce.js')}}"></script>

<script src="{{asset('public/app-assets/vendors/js/charts/apexcharts.min.js')}}"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

@stop

